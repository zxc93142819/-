
Run the following to download trained models.
```
python main_download_pretrained_models.py --models "SCUNet" --model_dir "model_zoo"
```



Our `scunet_color_real_psnr.pth` and `scunet_color_real_gan.pth` were trained with purely synthetic data! They work well on DND dataset!
